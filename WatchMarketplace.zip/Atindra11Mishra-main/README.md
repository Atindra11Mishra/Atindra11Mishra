This a watch store. 
Designed with HTML and CSS.

![1](https://user-images.githubusercontent.com/81668822/189527738-dd842f3d-d1c9-4b83-a553-6bf9ef29fee8.jpeg)

![5](https://user-images.githubusercontent.com/81668822/189527848-5cdf62b9-a4c8-4fbd-97c9-ece827bedabf.jpeg)

![6](https://user-images.githubusercontent.com/81668822/189527849-4e3c73a9-cf2a-473a-9865-5d6bb4ddf62a.jpeg)
